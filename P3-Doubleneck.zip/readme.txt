Run main.jl
Make sure all package are installed